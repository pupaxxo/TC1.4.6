To install, extract this zip file into your minecraft directory. The folder structure has already been setup for you.
If you encounter any crashes or issues, please refer to HowToGetFESupport.txt.
For reference this is ForgeEssentials version @VERSION@ for Minecraft version @MC@